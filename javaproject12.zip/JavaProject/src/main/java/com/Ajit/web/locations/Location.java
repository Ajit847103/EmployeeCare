package com.Ajit.web.locations;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Location {
	@Id
	private String id;

	private String Location_name;

	public Location() {
	}
	
	public Location(String id, String name) {
		super();
		this.id= id;
		this.Location_name= name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return Location_name;
	}

	public void setName(String name) {
		this.Location_name = name;
	}
}









