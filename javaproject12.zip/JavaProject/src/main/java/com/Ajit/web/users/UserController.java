package com.Ajit.web.users;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@RestController
public class UserController {
	
	@Autowired
	UserService us;

	@RequestMapping(value="/users")
	public ModelAndView GetAllUsers(Model model){
		model.addAttribute("user", us.getAllUsers());
		return modelView("users.html");
	}

	@RequestMapping(value="/users/{id}")
	public User getUserBy(@PathVariable String id){
		return us.getUser(id);
	}

	@GetMapping(value="/addusers")
	public ModelAndView addUser(Model model) {
		model.addAttribute("user", new User());
		return modelView("adduser.html");
	}

	@PostMapping(value="/addeduser")
	public ModelAndView addUser(@ModelAttribute("user") User user, Model model) {
		us.addUser(user);
		model.addAttribute("user",us.getAllUsers());
		return modelView("users.html");
	}

	@RequestMapping(method = RequestMethod.POST, value="/updateusers/{id}")
	public boolean updateUser(@RequestBody User user,@PathVariable String id) {
		return us.updateUser(id, user);
	}

	@RequestMapping(value="/deleteuser/{id}")
	public ModelAndView deleteUser(@PathVariable String id, Model model) {
		us.deleteUser(id);
		model.addAttribute("user", us.getAllUsers());
		return modelView("users.html");
	}

	@RequestMapping(value="/userbyfirstname/{firstname}")
	public Object getUserByFirstName(@PathVariable String firstname) {
		return us.getUserByFirstName(firstname);
	}

	@RequestMapping(value="/userbylastname/{lastname}")
	public List<User> getUserByLastName(@PathVariable String lastname) {
		return us.getUserByLastName(lastname);
	}

	public ModelAndView modelView(String mv) {
		ModelAndView modv = new ModelAndView();
		modv.setViewName(mv);
		return modv;
	}













//
//	@PostMapping(value="/Adduser")
//	public Object user(@RequestBody User user) {
//		if(userrepository.findById(user.getId()).isPresent()) {
//			return ("User already exists");
//		} else {
//			us.save(user);
//			return ("User added");
//		}
//	}

//	@GetMapping(value="/users")
//	public Object getAllUser(){
//		if(userrepository.findAll().isEmpty()) {
//			return ("User not found");
//		} else {
//			return us.findAll();
//		}
//	}
//
//	@RequestMapping(value="/user/{id}")
//	public Object getUserById(@PathVariable String id) {
//		if(userrepository.getUserById(id).isEmpty()) {
//			return "User not found";
//		} else {
//			return us.getUserById(id);
//		}
//	}
//
//	@PutMapping(value="/userupdate/{id}")
//	public String updateUserById(@PathVariable String id,
//								 @RequestBody User user) {
//		Optional<User> user1 = userrepository.findById(id);
//		if(user1.isPresent()) {
//			us.save1(user);
//			return "Updated";
//		} else {
//			return "User not found";
//		}
//	}
//
//	@DeleteMapping(value="/userdelete/{id}")
//	public String deleteUserById(@PathVariable String id) {
//		Optional<User> user = userrepository.findById(id);
//		if(user.isPresent()) {
//			us.delete(user.get());
//			return "Deleted";
//		} else {
//			return "User not found";
//		}
//	}
//
//
//
//
//
//
//	@RequestMapping(value="/users")
//	public ModelAndView getAllUsers(Model model){
//		model.addAttribute("users", us.getAllUsers());
//		return  modelAndView("users.html");
//	}
//
//
//	@RequestMapping(value="/users/{id}")
//	public User getUser(@PathVariable String id) {
//		return us.getUser(id);
//	}
//
//
//
//







//
//
//
//		@RequestMapping(value="/userbyfirstname/{firstname}")
//	public List<User> getUserByFirstName(@PathVariable String firstname) {
//		return us.getUserByFirstName(firstname);
//	}
//
//		ModelAndView modelAndView(String mv){
//		ModelAndView modv= new ModelAndView();
//		modv.setViewName(mv);
//		return modv;
//	}
}
