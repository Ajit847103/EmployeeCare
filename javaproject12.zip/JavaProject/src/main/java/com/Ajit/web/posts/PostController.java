package com.Ajit.web.posts;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.Ajit.web.users.UserRepository;

@RestController
public class PostController {

	@Autowired
	public PostRepository postrepository;
	@Autowired
	PostService us;

	@Autowired
	public UserRepository userRepository;

//	@PostMapping(value="/Addpost")
//	public String post(@RequestBody Post post) {
//		if(postrepository.findById(post.getId()).isPresent()){
//			return ("Post already exists");
//		}
//		else {
//			us.save(post);
//			return ("Post added");
//		}
//	}
//
//	@GetMapping(value="/getposts")
//	public List<Post> getAllPost(){
//		if(postrepository.findAll().isEmpty()) {
//			return null;
//		}
//		else {
//			return us.findAll();
//		}
//	}
//
//	@PutMapping(value="/postupdate/{id}")
//	public String updatePost(@PathVariable String id,
//							 @RequestBody Post post) {
//		Optional<Post> post1 = postrepository.findById(id);
//		if(((Optional<?>) post1).isPresent()) {
//			us.save1(post);
//			return "Updated";
//		}
//		else {
//			return "Post not found";
//		}
//	}
//
//	@RequestMapping(value = "/post/{id}")
//	public Object getPostById(@PathVariable String id) {
//		if(us.getPostById(id) == null) {
//			return ("Post not found");
//		}
//		else {
//			 return us.getPostById(id);
//		}
//	}
//
//	@DeleteMapping(value="/postdelete/{id}")
//	public String deletePost(@PathVariable String id) {
//		Optional<Post> post = postrepository.findById(id);
//		if(post.isPresent()) {
//			us.delete(post.get());
//			return "Deleted";
//		}
//		else {
//			return ("Post not found");
//		}
//	}
//
//	@RequestMapping(value="/getpostbydate/{date}")
//	public Object getPostByDate(@PathVariable String date) {
//		return us.getPostByDate(date);
//	}


	@RequestMapping(value="/posts")
	public ModelAndView getAllPosts(Model model){
		model.addAttribute("post", us.getAllPosts());
		return  modelView("post.html");
	}

	@GetMapping(value="/addpost")
	public ModelAndView addPost(Model model){
		model.addAttribute("post", new Post());
		return modelView("addpost.html");
	}

	@PostMapping(value="/addedpost")
	public ModelAndView post(@ModelAttribute("post") Post post, Model model) {
		us.addPost(post);
		model.addAttribute("post", us.getAllPosts());
		return modelView("post.html");
	}

	@RequestMapping(value="/deletepost/{id}")
	public ModelAndView deletePost(@PathVariable String id, Model model) {
		us.deletePost(id);
		model.addAttribute("post", us.getAllPosts());
		return modelView("post.html");
	}



	public ModelAndView modelView(String mv) {
		ModelAndView modv = new ModelAndView();
		modv.setViewName(mv);
		return modv;

	}

//	@RequestMapping(value="/posts")
//	public List<Post> getAllPost(){
//		return us.findAll();
//	}
//
//	@RequestMapping(value = "/posts/{id}")
//	public Post getPost(@PathVariable String id) {
//		return us.getPost(id);
//	}

//	@RequestMapping(method = RequestMethod.POST, value = "/addposts")
//	public void addPost(@RequestBody Post post) {
//		us.addPost(post);
//	}

//	@RequestMapping(method = RequestMethod.POST, value = "/updateposts/{id}")
//	public boolean updatePost(@RequestBody Post post, @PathVariable String id) {
//		return us.updatePost(id, post);
//	}


//	@RequestMapping(value = "/deletepost/{id}")
//	public ModelAndView deletePost(@PathVariable String id, Model model) {
//		us.deletePost(id);
//		return modelAndView("dashboard.html");
//	}



	@RequestMapping(value = "/post/{id}")
	public ModelAndView getPostByUser(@PathVariable String id, Model model) {
		model.addAttribute("post", us.getPostByUser(id));
		return modelView("post.html");
	}
//
//	@RequestMapping(value = "/postbydate/{date}")
//	public Object getPostByDate(@PathVariable String date) {
//		return ps.getPostByDate(date);
//	}
//

	}


















