package com.Ajit.web.locations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class LocationService {
	
	@Autowired
	 private LocationRepository locationrepository;
	

	//Add location by id.
	public void save(Location location) {
		locationrepository.save(location);
	}

	//Get locations.
	public Object findAll() {
	return locationrepository.findAll();
	}

	//Update location by id.
	public void save1(Location location) {
		locationrepository.save(location);
	}

	//Delete location by id.
	public void deleteLocationById(String id) {
		locationrepository.deleteById(id);
	}

    public Object getAllLocations() {
		return locationrepository.findAll();
    }
}













