package com.Ajit.web.posts;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PostService {
	@Autowired
	PostRepository postrepository;

//	public List<Post> getAllPosts() {
//		return postrepository.findAll();
//	}
//
//	public Post getPost(String id) {
//		return postrepository.findById(id).get();
//	}
//
//	public void addPost(Post post) {
//		postrepository.save(post);
//	}
//
//	public boolean updatePost(String id, Post post) {
//		if (postrepository.findById(id).isPresent()) {
//			postrepository.save(post);
//			return true;
//		} else {
//			return false;
//		}
//	}
//
//	public void deletePost(String id) {
//		postrepository.deleteById(id);
//	}
//
//	public Object getPostByUser(String id) {
//		return postrepository.findByUserId(id);
//	}
//
//	public Object getPostByDate(String date) {
//		return postrepository.getPostsByPostDate(date);
//	}


//	private ArrayList<Post> al=new ArrayList<Post>();
//	public List<Post> getAllPost(){
//		return al;
//	}

	//post Add.
	public void save(Post post) {
		postrepository.save(post);
	}

	//Get All Post.
	public List<Post> findAll() {
		return postrepository.findAll();
	}

	//Post Update by id.
	public void save1(Post post) {
		postrepository.save(post);
	}

	//Post Get by id.
	public Object getPostById(String id) {
		return postrepository.getPostById(id);
	}

	//post delete by id.
	public void delete(Post post) {
		postrepository.delete(post);
	}

	//post get by postdate.
    public Object getPostByDate(String date) {
		return postrepository.getPostsByPostDate(date);
    }

	public Post getPost(String id) {
		return postrepository.findById(id).get();
	}

	public void addPost(Post post) {
		postrepository.save(post);
	}

	public boolean updatePost(String id, Post post) {
		if (postrepository.findById(id).isPresent()) {
			postrepository.save(post);
			return true;
		} else {
			return false;
		}
	}

	public void deletePost(String id) {
		postrepository.deleteById(id);
	}

	public Object getPostByUser(String id) {
		return postrepository.findByUserId(id);
	}

    public Object getAllPosts() {
		return postrepository.findAll();
    }
}
