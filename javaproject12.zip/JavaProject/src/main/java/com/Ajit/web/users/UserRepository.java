package com.Ajit.web.users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, String>{
    //search users by first name.
    @Query("select u From User u Where u.firstname = :firstname")
    List<User> getUsersFirstName(String firstname);

    //search users by last name.
    @Query("select u From User u Where u.lastname = :lastname")
    List<User> getUsersLastName(String lastname);

    Optional<Object> getUserById(String id);


//    List<User> findByFirstName(String firstname);

//    List<User> findByLastName(String lastname);
}

