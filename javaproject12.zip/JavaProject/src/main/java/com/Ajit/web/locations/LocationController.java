package com.Ajit.web.locations;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class LocationController {
	@Autowired
	private LocationRepository locationrepository;
	@Autowired
	LocationService us;

	@RequestMapping(value="/locations")
	public ModelAndView GetAllLocations(Model model){
		model.addAttribute("location", us.getAllLocations());
		return modelView("locations.html");
	}

	@GetMapping(value="/addlocations")
	public ModelAndView addLocationa(Model model) {
		model.addAttribute("location", new Location());
		return modelView("addlocation.html");
	}

	@PostMapping(value="/Addedlocation")
	public ModelAndView addLocation(@ModelAttribute("location") Location location, Model model) {
		us.save(location);
		model.addAttribute("location", us.getAllLocations());
		return modelView("locations.html");
	}

	@RequestMapping(value= "/deletelocation/{id}")
	public ModelAndView deleteLocation(@PathVariable String id, Model model) {
		us.deleteLocationById(id);
		model.addAttribute("location", us.getAllLocations());
		return modelView("locations.html");
	}

	@PutMapping(value="/locationupdate/{id}")
	public String updateLocation(@PathVariable String id,
								 @RequestBody Location location) {
		Optional<Location> location1 = locationrepository.findById(id);
		if(location1.isPresent()) {
			us.save1(location);
			return ("New location is Updated");
		}
		else {
			return ("Location not found in database");
		}
	}

	public ModelAndView modelView(String mv) {
		ModelAndView modv = new ModelAndView();
		modv.setViewName(mv);
		return modv;
	}
}














