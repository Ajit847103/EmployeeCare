package com.Ajit.web.users;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

	@Autowired
	private UserRepository userrepository;

	private ArrayList<User> al=new ArrayList<User>();
	public ArrayList<User> getAllUser(){

//		User user1= new User(
//			"u1",
//			"Raushan",
//			"Kumar",
//			new Location("l1", "Raunak"),
//			"Gunjanrai.bhr2003@gmail.com");
//
//		User user2= new User(
//				"u2",
//				"Gunjan",
//				"Rai",
//				new Location("l2", "Ranjan"),
//				"Gunjanrai.bhr2003@gmail.com");
//		al.add(user1);
//		al.add(user2);
		return al;
	}


//	public Object getAllUsers() {
//	userrepository.findAll();
//		return null;
//	}
//
//	public User getUser(String id) {
//		return userrepository.findById(id).get();
//	}
//
//	public void addUser(User user) {
//		userrepository.save(user);
//	}
//
//	public boolean updateUser(String id, User user) {
//		userrepository.save(user);
//		return true;
//	}
//
//	public void deleteUser(String id) {
//		userrepository.deleteById(id);
//	}

	public List<User> getUserByFirstName(String firstname) {
		if(userrepository.getUsersFirstName(firstname).isEmpty()) {
			return null;
		} else {
			return userrepository.getUsersFirstName(firstname);
		}
	}

	public List<User> getUserByLastName(String lastname) {
		if(userrepository.getUsersLastName(lastname).isEmpty()) {
			return null;
		} else {
			return userrepository.getUsersLastName(lastname);
		}
	}

	public User getUser(String id) {
		if(userrepository.findById(id).isPresent()) {
			return userrepository.findById(id).get();
		} else {
			return null;
		}
	}


//	public void addUser(User user) {
//		if(userrepository.findById(user.getId()).isPresent()) {
//			System.out.println("User already exists");
//		} else {
//			userrepository.save(user);
//		}
//	}

	//update Existed  user by id.
	public void save1(User user) {
		userrepository.save(user);
	}

	//user by id.
	public void delete(User user) {
		userrepository.delete(user);
	}

	//Find user by id.
	public Object getUserById(String id) {
		return userrepository.getUserById(id);
	}

	//Find all user.
	public List<User> findAll() {
		return userrepository.findAll();
	}

	// save  new user.
	public void save(User user) {
		userrepository.save(user);
	}

	public Object getAllUsers() {
		return userrepository.findAll();
	}

	public boolean updateUser(String id, User user) {
		userrepository.save(user);
		return true;
	}

	public void deleteUser(String id) {
		userrepository.deleteById(id);
	}

	public Object getAllUser1() {
		return userrepository.findAll();
	}

	public void addUser(User user) {
		userrepository.save(user);
	}
}









